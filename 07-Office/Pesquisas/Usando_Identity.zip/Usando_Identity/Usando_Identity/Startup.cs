﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Usando_Identity.Startup))]
namespace Usando_Identity
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
